import { Component, AfterViewInit, OnDestroy, NgZone, Input, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { animate } from 'animejs';

@Component({
  selector: 'app-animated-wire',
  templateUrl: './animated-wire.component.html',
  styleUrls: ['./animated-wire.component.scss'],
  standalone: true,
  imports: [CommonModule]
})
export class AnimatedWireComponent implements AfterViewInit, OnDestroy {
  @Input() pathData: string = 'M10.37,2.29 L2.87,12.79 L30.37,17.54 L30.37,21.29 L63.22,20.06 L63.22,41.52';
  @Input() viewBox: string = '0 0 66 44';
  @Input() color: string = '#FFE000';
  @Input() duration: number = 3500;
  @Input() trailLength: number = 20;
  @Input() autoStart: boolean = true;
  @Input() reverse: boolean = false;

  @ViewChild('svgRef') svgRef!: ElementRef<SVGSVGElement>;
  @ViewChild('pathRef') pathRef!: ElementRef<SVGPathElement>;
  @ViewChild('particlesGroup') particlesGroup!: ElementRef<SVGGElement>;

  public instanceId = Math.random().toString(36).substring(2, 9);
  private animation: any;
  private destroyed = false;
  private isPaused = false;
  private currentParticle: any;

  constructor(private ngZone: NgZone) {}

  ngAfterViewInit() {
    if (this.autoStart) {
      this.ngZone.runOutsideAngular(() => {
        setTimeout(() => this.startFlow(), 400);
      });
    }
  }

  public start() {
    this.isPaused = false;
    if (!this.animation) {
      this.startFlow();
    } else {
      this.animation.play();
    }
  }

  public stop() {
    this.isPaused = true;
    if (this.animation) {
      this.animation.pause();
    }
  }

  public toggleReverse(isReverse: boolean) {
    this.reverse = isReverse;
    this.restart();
  }

  public restart() {
    this.stop();
    if (this.currentParticle && this.currentParticle.parentNode) {
      this.currentParticle.parentNode.removeChild(this.currentParticle);
    }
    this.animation = null;
    this.startFlow();
  }

  private startFlow() {
    if (this.destroyed || this.isPaused) return;
    this.runSingleParticle();
  }

  private runSingleParticle() {
    const svg = this.svgRef.nativeElement;
    const group = this.particlesGroup.nativeElement;
    const pathEl = this.pathRef.nativeElement;

    if (!svg || !group || !pathEl) return;

    // Get total length
    const totalLen = pathEl.getTotalLength();

    // Reset wire glow trail
    pathEl.style.strokeDasharray = `${this.trailLength} ${totalLen}`;
    pathEl.style.strokeDashoffset = this.reverse ? String(-(totalLen + this.trailLength)) : String(this.trailLength);

    // Create particle
    const particle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    particle.setAttribute('r', '2.5'); // Reduced size
    particle.setAttribute('fill', `url(#electricGrad-${this.instanceId})`);
    particle.setAttribute('opacity', '0');
    group.appendChild(this.currentParticle = particle);

    const progress = { t: 0 };
    const totalPath = totalLen + this.trailLength;

    this.animation = animate(progress, {
      t: 1,
      duration: this.duration,
      easing: 'linear',
      onUpdate: () => {
        const t = progress.t;
        
        // Calculate the center position of the trail segment
        let currentDist: number;
        if (!this.reverse) {
          currentDist = t * totalPath;
        } else {
          currentDist = (1 - t) * totalPath;
        }

        const dashStart = this.reverse ? currentDist : currentDist - this.trailLength;
        pathEl.style.strokeDashoffset = String(-dashStart);

        // Particle should only exist while currentDist is within [0, totalLen]
        if (currentDist >= 0 && currentDist <= totalLen) {
          const pt = pathEl.getPointAtLength(currentDist);
          particle.setAttribute('cx', String(pt.x));
          particle.setAttribute('cy', String(pt.y));
          particle.setAttribute('opacity', '0.9');
        } else {
          particle.setAttribute('opacity', '0');
        }
      },
      onComplete: () => {
        if (particle.parentNode) group.removeChild(particle);
        pathEl.style.strokeDashoffset = this.reverse ? String(-(totalLen + this.trailLength)) : String(this.trailLength);

        if (!this.destroyed && !this.isPaused) {
          setTimeout(() => this.startFlow(), 900);
        }
      }
    });
  }

  ngOnDestroy() {
    this.destroyed = true;
    if (this.animation) {
      this.animation.pause();
    }
  }
}
